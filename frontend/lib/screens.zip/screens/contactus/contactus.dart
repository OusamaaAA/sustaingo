import 'package:flutter/material.dart';
import '../../constants.dart';

class ContactUsScreen extends StatelessWidget {
  const ContactUsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Contact Us', style: TextStyle(color: Colors.white)),
        backgroundColor: const Color(0xFF2d6a4f),
        iconTheme: const IconThemeData(color: Colors.white),
        elevation: 4,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(20),
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(defaultPadding),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Get in Touch with SustainGo',
              style: Theme.of(context).textTheme.headlineSmall!.copyWith(
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
            ),
            const SizedBox(height: defaultPadding / 2),
            Text(
              'We\'re here to help and answer any questions you might have. Reach out to us through the following channels:',
              style: Theme.of(context).textTheme.bodyMedium!.copyWith(
                color: Colors.black54,
              ),
            ),
            const SizedBox(height: defaultPadding * 1.5),
            _buildContactInfoCard(
              context: context,
              icon: Icons.email_outlined,
              title: 'Email & Inquiries',
              content: 'For general inquiries, support, and partnership opportunities, please email us at:',
              detail: 'support@sustaingo.com',
              isLink: true,
              link: 'mailto:support@sustaingo.com',
            ),
            const SizedBox(height: defaultPadding),
            _buildContactInfoCard(
              context: context,
              icon: Icons.phone_outlined,
              title: 'Phone Number',
              content: 'You can also reach us by phone during our business hours 8:00 AM to 4:00 PM:',
              detail: '+961 1 300 599',
              isLink: true,
              link: 'tel:+9611300599',
            ),
            const SizedBox(height: defaultPadding * 1.5),
            Text(
              'More Information',
              style: Theme.of(context).textTheme.titleMedium!.copyWith(
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
            ),
            const SizedBox(height: defaultPadding / 2),
            Text(
              'At SustainGo, we are passionate about connecting individuals with opportunities to save delicious food and contribute to a more sustainable future. We partner with local restaurants, cafes, and bakeries in Beirut to offer discounted surplus food.',
              style: Theme.of(context).textTheme.bodyMedium!.copyWith(
                color: Colors.black54,
              ),
            ),
            const SizedBox(height: defaultPadding / 2),
            Text(
              'Our mission is to reduce food waste and make quality food more accessible to everyone in Beirut. By using SustainGo, you are not only saving money but also making a positive impact on our community and the environment.',
              style: Theme.of(context).textTheme.bodyMedium!.copyWith(
                color: Colors.black54,
              ),
            ),
            const SizedBox(height: defaultPadding * 1.5),
            Text(
              'Operating in Beirut, Lebanon',
              style: Theme.of(context).textTheme.bodySmall!.copyWith(
                color: Colors.black45,
              ),
            ),
            const SizedBox(height: defaultPadding),
            const Divider(color: Colors.grey, thickness: 0.5),
            const SizedBox(height: defaultPadding / 2),
            Center(
              child: Text(
                'Thank you for connecting with SustainGo!',
                style: Theme.of(context).textTheme.bodySmall!.copyWith(
                  color: Colors.black54,
                  fontStyle: FontStyle.italic,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildContactInfoCard({
    required BuildContext context,
    required IconData icon,
    required String title,
    required String content,
    required String detail,
    bool isLink = false,
    String? link,
  }) {
    return Container(
      padding: const EdgeInsets.all(defaultPadding),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        boxShadow: [
          BoxShadow(
            offset: const Offset(0, 2),
            blurRadius: 4,
            color: Colors.black12.withOpacity(0.08),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: const Color(0xFF2d6a4f)),
              const SizedBox(width: defaultPadding / 2),
              Text(
                title,
                style: Theme.of(context).textTheme.titleMedium!.copyWith(
                  fontWeight: FontWeight.w600,
                  color: Colors.black87,
                ),
              ),
            ],
          ),
          const SizedBox(height: defaultPadding / 2),
          Text(
            content,
            style: Theme.of(context).textTheme.bodyMedium!.copyWith(
              color: Colors.black54,
            ),
          ),
          const SizedBox(height: defaultPadding / 4),
          if (isLink && link != null)
            InkWell(
              onTap: () {
                // You'll need to implement a way to open URLs or phone calls
                // using packages like 'url_launcher'.
                // For now, we'll just print the link.
                print('Opening: $link');
                // Example using url_launcher (you need to add this dependency):
                // launchUrl(Uri.parse(link));
              },
              child: Text(
                detail,
                style: Theme.of(context).textTheme.bodyLarge!.copyWith(
                  color: const Color(0xFF2d6a4f),
                  fontWeight: FontWeight.bold,
                ),
              ),
            )
          else
            Text(
              detail,
              style: Theme.of(context).textTheme.bodyLarge!.copyWith(
                color: Colors.black87,
                fontWeight: FontWeight.bold,
              ),
            ),
        ],
      ),
    );
  }
}