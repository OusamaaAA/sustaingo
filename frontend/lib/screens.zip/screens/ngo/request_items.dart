import 'package:flutter/material.dart';

class RequestItemsBottomSheet extends StatelessWidget {
  final List<Map<String, dynamic>> availableItems;
  final String vendorName;
  final String pickupStart;
  final String pickupEnd;
  final VoidCallback onReserve;

  const RequestItemsBottomSheet({
    super.key,
    required this.availableItems,
    required this.vendorName,
    required this.pickupStart,
    required this.pickupEnd,
    required this.onReserve,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16.0),
      decoration: const BoxDecoration(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            "Donation Bag from $vendorName",
            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          Text("Pickup Time: $pickupStart - $pickupEnd", style: const TextStyle(color: Colors.grey)),
          const SizedBox(height: 16),
          ...availableItems.map(
            (item) => ListTile(
              title: Text(item['name'] ?? 'Item'),
              subtitle: Text("Quantity: ${item['quantity'] ?? 'N/A'}"),
              leading: const Icon(Icons.fastfood),
            ),
          ),
          const SizedBox(height: 20),
          ElevatedButton.icon(
            onPressed: onReserve,
            icon: const Icon(Icons.shopping_bag),
            label: const Text("Reserve This Bag"),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF2d6a4f),
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            ),
          ),
        ],
      ),
    );
  }
}
