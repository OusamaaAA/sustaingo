import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../../constants.dart';

class DelivOrderDetails extends StatefulWidget {
  final Map<String, dynamic> delivery;
  final Function(String) onStatusUpdate;

  const DelivOrderDetails({
    super.key,
    required this.delivery,
    required this.onStatusUpdate,
  });

  @override
  State<DelivOrderDetails> createState() => _DelivOrderDetailsState();
}

class _DelivOrderDetailsState extends State<DelivOrderDetails> {
  late Map<String, dynamic> _delivery;

  @override
  void initState() {
    super.initState();
    _delivery = Map.from(widget.delivery);
  }

  Widget _buildOrderItem(BuildContext context, String name, double price) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            name,
            style: Theme.of(context).textTheme.bodyMedium,
          ),
          Text(
            '\$$price',
            style: Theme.of(context).textTheme.bodyMedium,
          ),
        ],
      ),
    );
  }

  void _updateStatus() {
    String newStatus = _delivery['status']; // Initialize with current status

    setState(() {
      if (_delivery['status'] == 'pickup') {
        newStatus = 'delivery';
      } else if (_delivery['status'] == 'delivery') {
        newStatus = 'completed';
      }
      _delivery['status'] = newStatus;
    });

    // Call the callback with the new status
    widget.onStatusUpdate(newStatus);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final statusColor = _delivery['status'] == 'completed'
        ? Colors.green
        : _delivery['status'] == 'pickup'
        ? Colors.orange
        : Colors.blue;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Order ${_delivery['id']}',
          style: const TextStyle(color: Colors.white),
        ),
        backgroundColor: const Color(0xFF2d6a4f),
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(defaultPadding),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Order Status Card
            Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              elevation: 2,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: statusColor.withOpacity(0.1),
                            shape: BoxShape.circle,
                          ),
                          child: Icon(
                            _delivery['status'] == 'completed'
                                ? Icons.check_circle
                                : _delivery['status'] == 'pickup'
                                ? Icons.store
                                : Icons.delivery_dining,
                            color: statusColor,
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                _delivery['status'] == 'completed'
                                    ? 'Delivery Completed'
                                    : _delivery['status'] == 'pickup'
                                    ? 'Ready for Pickup'
                                    : 'On the Way',
                                style: theme.textTheme.titleMedium?.copyWith(
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                _delivery['status'] == 'completed'
                                    ? 'Order was delivered successfully'
                                    : _delivery['status'] == 'pickup'
                                    ? 'Pick up from restaurant'
                                    : 'Delivering to customer',
                                style: theme.textTheme.bodySmall,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    LinearProgressIndicator(
                      value: _delivery['status'] == 'completed'
                          ? 1.0
                          : _delivery['status'] == 'pickup'
                          ? 0.33
                          : 0.66,
                      backgroundColor: Colors.grey[200],
                      color: const Color(0xFF2d6a4f),
                      minHeight: 8,
                      borderRadius: BorderRadius.circular(4),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Order placed',
                          style: theme.textTheme.bodySmall,
                        ),
                        Text(
                          'Picked up',
                          style: theme.textTheme.bodySmall,
                        ),
                        Text(
                          'Delivered',
                          style: theme.textTheme.bodySmall,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),

            // Restaurant Info
            Text(
              'RESTAURANT',
              style: theme.textTheme.labelMedium?.copyWith(
                color: Colors.grey,
              ),
            ),
            const SizedBox(height: 8),
            Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              elevation: 1,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    Container(
                      width: 60,
                      height: 60,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        color: Colors.grey[200],
                      ),
                      child: const Icon(Icons.store, size: 30, color: Colors.grey),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            _delivery['restaurant'],
                            style: theme.textTheme.titleMedium?.copyWith(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'Pickup by: 12:30 PM',
                            style: theme.textTheme.bodySmall,
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      icon: SvgPicture.asset(
                        'assets/icons/call.svg',
                        height: 24,
                        colorFilter: const ColorFilter.mode(
                          Color(0xFF2d6a4f),
                          BlendMode.srcIn,
                        ),
                      ),
                      onPressed: () {
                        // Call restaurant
                      },
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),

            // Customer Info
            Text(
              'CUSTOMER',
              style: theme.textTheme.labelMedium?.copyWith(
                color: Colors.grey,
              ),
            ),
            const SizedBox(height: 8),
            Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              elevation: 1,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    Container(
                      width: 60,
                      height: 60,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        color: Colors.grey[200],
                      ),
                      child: const Icon(Icons.person, size: 30, color: Colors.grey),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            _delivery['customer'],
                            style: theme.textTheme.titleMedium?.copyWith(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            _delivery['address'],
                            style: theme.textTheme.bodySmall,
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      icon: SvgPicture.asset(
                        'assets/icons/call.svg',
                        height: 24,
                        colorFilter: const ColorFilter.mode(
                          Color(0xFF2d6a4f),
                          BlendMode.srcIn,
                        ),
                      ),
                      onPressed: () {
                        // Call customer
                      },
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),

            // Order Summary
            Text(
              'ORDER SUMMARY',
              style: theme.textTheme.labelMedium?.copyWith(
                color: Colors.grey,
              ),
            ),
            const SizedBox(height: 8),
            Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              elevation: 1,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    _buildOrderItem(context, 'Mystery Bag (Large)', 12.00),
                    const Divider(),
                    _buildOrderItem(context, 'Rescued Pasta', 6.50),
                    const Divider(),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Subtotal',
                          style: theme.textTheme.bodyMedium,
                        ),
                        Text(
                          '\$${_delivery['price']}',
                          style: theme.textTheme.bodyMedium,
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Delivery Fee',
                          style: theme.textTheme.bodyMedium,
                        ),
                        Text(
                          '\$2.50',
                          style: theme.textTheme.bodyMedium,
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Total',
                          style: theme.textTheme.bodyMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          '\$${(_delivery['price'] + 2.5).toStringAsFixed(2)}',
                          style: theme.textTheme.bodyMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),

            // Action Buttons
            if (_delivery['status'] != 'completed')
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF2d6a4f),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        padding: const EdgeInsets.symmetric(vertical: 16),
                      ),
                      onPressed: _updateStatus,
                      child: Text(
                        _delivery['status'] == 'pickup'
                            ? 'PICKED UP'
                            : 'DELIVERED',
                        style: const TextStyle(color: Colors.white),
                      ),
                    ),
                  ),
                ],
              ),
          ],
        ),
      ),
    );
  }
}