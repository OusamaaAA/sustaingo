import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../../../components/price_range_and_food_type.dart';
import '../../../components/rating_with_counter.dart';
import '../../../constants.dart';
import '../view_all.dart';
class RestaurantInfo extends StatelessWidget {
  final Map<String, dynamic> vendor;

  const RestaurantInfo({super.key, required this.vendor});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: defaultPadding),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            vendor['name'] ?? 'Vendor Name',
            style: theme.textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w700),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: defaultPadding / 2),
          const PriceRangeAndFoodtype(
            foodType: ["Mystery Bag"],
          ),
          const SizedBox(height: defaultPadding / 2),
          RatingWithCounter(
            rating: vendor['average_rating']?.toDouble() ?? 0.0,
            numOfRating: 200,
          ),
          const SizedBox(height: defaultPadding),
          Row(
            children: [
              DeliveryInfo(
                iconSrc: "assets/icons/delivery.svg",
                text: vendor['delivery_available'] == true ? "Free" : "Not Available",
                subText: "Delivery",
                iconColor: theme.colorScheme.primary,
              ),
              const SizedBox(width: defaultPadding),
              DeliveryInfo(
                iconSrc: "assets/icons/clock.svg",
                text: "${vendor['delivery_time_minutes']}",
                subText: "Minutes",
                iconColor: theme.colorScheme.secondary,
              ),
              const Spacer(),
              OutlinedButton(
                onPressed: () {},
                style: OutlinedButton.styleFrom(
                  foregroundColor: theme.colorScheme.primary,
                  side: BorderSide(color: theme.colorScheme.primary),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                ),
                child: const Text("Call", style: TextStyle(fontWeight: FontWeight.w600)),
              ),
            ],
          ),
          const SizedBox(height: defaultPadding * 2),
          Text(
            "Restaurant Reviews",
            style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: defaultPadding),
          _buildReviewItem(
            context,
            name: "Nadim Hamzeh",
            rating: 5,
            comment: "The food was exceptional and the service was top-notch. Highly recommended!",
            date: "April 17, 2025",
          ),
          _buildReviewItem(
            context,
            name: "Ahmad Chahine",
            rating: 4,
            comment: "Great food with a cozy ambiance. Delivery was also quick.",
            date: "April 16, 2025",
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: defaultPadding),
            child: Align(
              alignment: Alignment.centerRight,
              child: TextButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ViewAllReviewsScreen(
                        vendorId: vendor['id'], // This can be int or String
                        vendorName: vendor['name'] ?? 'Restaurant',
                      ),
                    ),
                  );
                },
                style: TextButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  backgroundColor: const Color(0xFF2d6a4f).withOpacity(0.1),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      "View All Reviews",
                      style: TextStyle(
                        color: Color(0xFF2d6a4f),
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(width: 4),
                    Icon(
                      Icons.arrow_forward,
                      size: 16,
                      color: Color(0xFF2d6a4f),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: defaultPadding),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () {
                showModalBottomSheet(
                  context: context,
                  isScrollControlled: true,
                  builder: (BuildContext context) {
                    return _buildAddReviewBottomSheet(context);
                  },
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: theme.colorScheme.primary,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                padding: const EdgeInsets.symmetric(vertical: 16),
              ),
              child: const Text("Add a Review", style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16)),
            ),
          ),
          const SizedBox(height: defaultPadding),
        ],
      ),
    );
  }

  Widget _buildAddReviewBottomSheet(BuildContext context) {
    final theme = Theme.of(context);
    double _rating = 0;
    final TextEditingController _reviewController = TextEditingController();

    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
        left: defaultPadding,
        right: defaultPadding,
        top: defaultPadding,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("Write a Review", style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700)),
          const SizedBox(height: defaultPadding),
          Text("Rating:", style: theme.textTheme.titleMedium),
          RatingBar.builder(
            initialRating: _rating,
            minRating: 1,
            direction: Axis.horizontal,
            allowHalfRating: false,
            itemCount: 5,
            itemPadding: const EdgeInsets.symmetric(horizontal: 4.0),
            itemBuilder: (context, _) => Icon(
              Icons.star_rounded,
              color: Colors.amber.shade400,
            ),
            onRatingUpdate: (rating) {
              _rating = rating;
            },
          ),
          const SizedBox(height: defaultPadding),
          Text("Your Review:", style: theme.textTheme.titleMedium),
          TextField(
            controller: _reviewController,
            maxLines: 3,
            decoration: InputDecoration(
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
              hintText: "Share your experience...",
            ),
          ),
          const SizedBox(height: defaultPadding * 2),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text("Thank you for your review!")),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: theme.colorScheme.secondary,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                padding: const EdgeInsets.symmetric(vertical: 16),
              ),
              child: const Text("Submit Review", style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16)),
            ),
          ),
          const SizedBox(height: defaultPadding),
        ],
      ),
    );
  }

  Widget _buildReviewItem(BuildContext context, {
    required String name,
    required double rating,
    required String comment,
    required String date,
  }) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: defaultPadding / 2),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(name, style: theme.textTheme.bodyLarge?.copyWith(fontWeight: FontWeight.w600)),
              const SizedBox(width: 8),
              RatingBarIndicator(
                rating: rating,
                itemBuilder: (context, _) => Icon(
                  Icons.star_rounded,
                  color: Colors.amber.shade400,
                ),
                itemSize: 20,
              ),
              const Spacer(),
              Text(date, style: theme.textTheme.bodySmall?.copyWith(color: Colors.grey)),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            comment,
            style: theme.textTheme.bodyMedium,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: defaultPadding / 2),
          const Divider(thickness: 0.8, color: Colors.grey),
        ],
      ),
    );
  }
}

class DeliveryInfo extends StatelessWidget {
  const DeliveryInfo({
    super.key,
    required this.iconSrc,
    required this.text,
    required this.subText,
    required this.iconColor,
  });

  final String iconSrc, text, subText;
  final Color iconColor;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SvgPicture.asset(
          iconSrc,
          height: 22,
          width: 22,
          colorFilter: ColorFilter.mode(
            iconColor,
            BlendMode.srcIn,
          ),
        ),
        const SizedBox(width: 10),
        Text.rich(
          TextSpan(
            text: text,
            style: theme.textTheme.labelLarge?.copyWith(fontWeight: FontWeight.w600),
            children: [
              TextSpan(
                text: "\n$subText",
                style: theme.textTheme.bodySmall?.copyWith(color: Colors.grey),
              )
            ],
          ),
        ),
      ],
    );
  }
}
