import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '../../constants.dart';
import 'components/items.dart';
import 'components/restaurrant_info.dart';

class DetailsScreen extends StatelessWidget {
  final Map<String, dynamic> vendor;

  const DetailsScreen({super.key, required this.vendor});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back,
            color: Colors.white,
          ),
          onPressed: () => Navigator.pop(context),
        ),
        title: Row(
          children: const [
            Icon(
              Icons.restaurant_outlined,
              color: Colors.white,
            ),
            SizedBox(width: 8.0),
            Text(
              "Restaurant Details",
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 20,
              ),
            ),
          ],
        ),
        centerTitle: true,
        backgroundColor: const Color(0xFF2d6a4f),
        elevation: 4,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(20),
          ),
        ),
        actions: [
          IconButton(
            icon: SvgPicture.asset("assets/icons/share.svg", color: Colors.white),
            onPressed: () {},
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: defaultPadding / 2),
              RestaurantInfo(vendor: vendor),
              const SizedBox(height: defaultPadding),
              Items(vendorId: vendor['id']),
            ],
          ),
        ),
      ),
    );
  }
}