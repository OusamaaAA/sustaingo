import 'package:flutter/material.dart';
import '../../../services/api_service.dart';
import '../../../components/cards/item_card.dart';
import '../../../constants.dart';
import '../../reserve/reserve_checkout.dart';

class Items extends StatefulWidget {
  final int vendorId;

  const Items({super.key, required this.vendorId});

  @override
  State<Items> createState() => _ItemsState();
}

class _ItemsState extends State<Items> {
  late Future<List<dynamic>> _mysteryBags;

  @override
  void initState() {
    super.initState();
    _mysteryBags = ApiService().fetchMysteryBagsByVendor(widget.vendorId);
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<dynamic>>(
      future: _mysteryBags,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        } else if (snapshot.hasError) {
          return Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text("Error loading items: ${snapshot.error}"),
          );
        } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
          return const Padding(
            padding: EdgeInsets.all(16.0),
            child: Text("No mystery bags available."),
          );
        }

        return Column(
          children: snapshot.data!.map((bag) {
            final double price = double.tryParse(bag['price'].toString()) ?? 0.0;

            return Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: defaultPadding,
                vertical: defaultPadding / 2,
              ),
              child: ItemCard(
                title: bag['title'] ?? '',
                description: bag['description'] ?? '',
                image: 'assets/images/featured_items_1.png', // Placeholder
                foodType: 'Mystery Bag',
                price: price,
                priceRange: "\$" * 2,
                press: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => AddToOrderScreen(
                      bagId: bag['id'],
                      title: bag['title'],
                      description: bag['description'],
                      price: price,
                    ),
                  ),
                ),
              ),
            );
          }).toList(),
        );
      },
    );
  }
}
