import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../../constants.dart';
import '../../../screens/auth/sign_in_screen.dart';

class DelivProfileScreen extends StatefulWidget {
  const DelivProfileScreen({super.key});

  @override
  State<DelivProfileScreen> createState() => _DelivProfileScreenState();
}

class _DelivProfileScreenState extends State<DelivProfileScreen> {
  bool _isEditing = false;
  bool _isLoading = true;
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _emailController = TextEditingController();
  final _plateController = TextEditingController();
  String? _selectedVehicle;
  String? _updateErrorMessage;

  // List of supported vehicle types
  final List<String> _vehicleTypes = [
    'Motorcycle',
    'Bicycle',
    'Car',
    'Scooter',
    'Electric Bike',
    'Walking'
  ];

  @override
  void initState() {
    super.initState();
    _fetchProfileData();
  }

  Future<void> _fetchProfileData() async {
    setState(() {
      _isLoading = true;
    });

    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('auth_token');

    try {
      // Simulate API call - replace with your actual endpoint
      await Future.delayed(const Duration(seconds: 1));

      // Mock response - replace with actual API response
      final mockResponse = {
        'name': 'Ali Hassan',
        'phone': '76123456',
        'email': 'ali.hassan@example.com',
        'vehicle_type': 'Motorcycle',
        'plate_number': 'BE 12345'
      };

      setState(() {
        _nameController.text = mockResponse['name'] ?? '';
        _phoneController.text = mockResponse['phone'] ?? '';
        _emailController.text = mockResponse['email'] ?? '';
        _selectedVehicle = mockResponse['vehicle_type'];
        _plateController.text = mockResponse['plate_number'] ?? '';
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
        _updateErrorMessage = 'Failed to load profile data';
      });
    }
  }

  Future<void> _updateProfile() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _updateErrorMessage = null;
      });

      final prefs = await SharedPreferences.getInstance();
      final token = prefs.getString('auth_token');

      try {
        // Simulate API call - replace with your actual endpoint
        await Future.delayed(const Duration(seconds: 1));

        // Here you would normally make the API call:
        /*
        final response = await http.patch(
          Uri.parse('your_api_endpoint/delivery_profile'),
          headers: {
            'Authorization': 'Bearer $token',
            'Content-Type': 'application/json',
          },
          body: jsonEncode({
            'name': _nameController.text,
            'phone': _phoneController.text,
            'email': _emailController.text,
            'vehicle_type': _selectedVehicle,
            'plate_number': _plateController.text,
          }),
        );

        if (response.statusCode != 200) {
          throw Exception('Failed to update profile');
        }
        */

        // On success
        setState(() {
          _isEditing = false;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Profile updated successfully!')),
        );
      } catch (e) {
        setState(() {
          _updateErrorMessage = 'Failed to update profile. Please try again.';
        });
      }
    }
  }

  void _logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('auth_token');
    await prefs.remove('refresh_token');

    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (context) => const SignInScreen()),
          (route) => false,
    );
  }

  // Phone number validation
  String? _validatePhone(String? value) {
    if (value == null || value.isEmpty) {
      return 'Please enter phone number';
    }
    // Lebanese phone number pattern (adjust as needed)
    final phoneRegex = RegExp(r'^[0-9]{7,8}$');
    if (!phoneRegex.hasMatch(value)) {
      return 'Please enter a valid Lebanese phone number';
    }
    return null;
  }

  // Email validation
  String? _validateEmail(String? value) {
    if (value == null || value.isEmpty) {
      return 'Please enter email address';
    }
    final emailRegex = RegExp(
      r'^[a-zA-Z0-9.!#$%&*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$',
    );
    if (!emailRegex.hasMatch(value)) {
      return 'Please enter a valid email address';
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Delivery Profile",
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        backgroundColor: const Color(0xFF2d6a4f),
        elevation: 2,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(bottom: Radius.circular(15)),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Form(
        key: _formKey,
        child: Stack(
          children: [
            SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: defaultPadding),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: defaultPadding * 1.5),
                  Center(
                    child: Column(
                      children: [
                        CircleAvatar(
                          radius: 50,
                          backgroundColor: const Color(0xFF2d6a4f),
                          child: SvgPicture.asset(
                            'assets/icons/vehicle.svg',
                            colorFilter: const ColorFilter.mode(Colors.blue, BlendMode.srcIn),
                            width: 24,
                            height: 24,
                          ),
                        ),
                        const SizedBox(height: defaultPadding / 2),
                        Text(
                          _isEditing ? 'Edit Profile' : _nameController.text,
                          style: const TextStyle(
                              fontSize: 26,
                              fontWeight: FontWeight.w700),
                        ),
                        const SizedBox(height: defaultPadding),
                      ],
                    ),
                  ),
                  ModernProfileTaskCard(
                    svgSrc: "assets/icons/phone.svg",
                    title: "Phone Number",
                    subTitle: _isEditing ? null : _phoneController.text,
                    color: const Color(0xFFE67E22),
                    press: () {},
                    child: _isEditing
                        ? TextFormField(
                      controller: _phoneController,
                      decoration: const InputDecoration(
                          labelText: 'Phone Number',
                          hintText: 'eg: 76 123 456'),
                      keyboardType: TextInputType.phone,
                      validator: _validatePhone,
                    )
                        : null,
                  ),
                  ModernProfileTaskCard(
                    svgSrc: "assets/icons/mail.svg",
                    title: "Email Address",
                    subTitle: _isEditing ? null : _emailController.text,
                    color: const Color(0xFF3498DB),
                    press: () {},
                    child: _isEditing
                        ? TextFormField(
                      controller: _emailController,
                      decoration: const InputDecoration(
                          labelText: 'Email Address'),
                      keyboardType: TextInputType.emailAddress,
                      validator: _validateEmail,
                    )
                        : null,
                  ),
                  ModernProfileTaskCard(
                    svgSrc: "assets/icons/directions_bike.svg",
                    title: "Vehicle Type",
                    subTitle: _isEditing ? null : _selectedVehicle,
                    color: const Color(0xFF9B59B6),
                    press: () {},
                    child: _isEditing
                        ? DropdownButtonFormField<String>(
                      value: _selectedVehicle,
                      decoration: const InputDecoration(
                          labelText: 'Vehicle Type'),
                      items: _vehicleTypes.map((String value) {
                        return DropdownMenuItem<String>(
                          value: value,
                          child: Text(value),
                        );
                      }).toList(),
                      onChanged: (newValue) {
                        setState(() {
                          _selectedVehicle = newValue;
                        });
                      },
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please select vehicle type';
                        }
                        return null;
                      },
                    )
                        : null,
                  ),
                  ModernProfileTaskCard(
                    svgSrc: "assets/icons/confirmation_number.svg",
                    title: "Plate Number",
                    subTitle: _isEditing ? null : _plateController.text,
                    color: const Color(0xFF60A917),
                    press: () {},
                    child: _isEditing
                        ? TextFormField(
                      controller: _plateController,
                      decoration: const InputDecoration(
                          labelText: 'Plate Number'),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter plate number';
                        }
                        return null;
                      },
                    )
                        : null,
                  ),
                  const SizedBox(height: defaultPadding * 1.5),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        if (_isEditing) {
                          _updateProfile();
                        } else {
                          setState(() {
                            _isEditing = true;
                          });
                        }
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _isEditing
                            ? const Color(0xFF3498DB)
                            : const Color(0xFF2d6a4f),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10)),
                      ),
                      child: Text(
                        _isEditing ? 'Save Changes' : 'Edit Profile',
                        style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w500),
                      ),
                    ),
                  ),
                  const SizedBox(height: defaultPadding / 2),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: _logout,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFE74C3C),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10)),
                      ),
                      child: const Text(
                        'Log Out',
                        style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w500),
                      ),
                    ),
                  ),
                  const SizedBox(height: defaultPadding),
                ],
              ),
            ),
            if (_updateErrorMessage != null)
              Positioned(
                bottom: 20,
                left: 20,
                right: 20,
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.redAccent,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    _updateErrorMessage!,
                    style: const TextStyle(color: Colors.white),
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class ModernProfileTaskCard extends StatelessWidget {
  const ModernProfileTaskCard({
    super.key,
    this.title,
    this.subTitle,
    this.svgSrc,
    this.press,
    this.color,
    this.child,
  });

  final String? title, subTitle, svgSrc;
  final VoidCallback? press;
  final Color? color;
  final Widget? child;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: defaultPadding / 3),
      child: InkWell(
        borderRadius: BorderRadius.circular(10),
        onTap: press,
        child: Container(
          decoration: BoxDecoration(
            color: color?.withOpacity(0.08) ?? Colors.grey.withOpacity(0.03),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: Colors.grey.shade200, width: 1),
          ),
          padding: const EdgeInsets.all(defaultPadding),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: color?.withOpacity(0.8) ?? Colors.grey.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: SvgPicture.asset(
                  svgSrc!,
                  height: 22,
                  width: 22,
                  colorFilter: ColorFilter.mode(
                      color ?? Colors.grey,
                      BlendMode.srcIn),
                ),
              ),
              const SizedBox(width: defaultPadding),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title!,
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                        color: Colors.grey.shade800,
                      ),
                    ),
                    if (child == null && subTitle != null && subTitle!.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(top: 3.0),
                        child: Text(
                          subTitle!,
                          style: TextStyle(
                              fontSize: 14,
                              color: Colors.grey.shade600),
                        ),
                      ),
                    if (child != null) child!,
                  ],
                ),
              ),
              if (child == null)
                const Icon(Icons.arrow_forward_ios,
                    color: Colors.grey,
                    size: 18),
            ],
          ),
        ),
      ),
    );
  }
}