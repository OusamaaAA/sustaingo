// ✅ Refined Donation Bag Card for NGO View with consistent height and structure
import 'package:flutter/material.dart';

class RestaurantInfoBigCardNgo extends StatelessWidget {
  final String bagTitle;
  final String description;
  final String vendorName;
  final int quantity;
  final String pickupStart;
  final String pickupEnd;
  final VoidCallback press;

  const RestaurantInfoBigCardNgo({
    super.key,
    required this.bagTitle,
    required this.description,
    required this.vendorName,
    required this.quantity,
    required this.pickupStart,
    required this.pickupEnd,
    required this.press,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 240,
      child: Card(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        elevation: 4,
        margin: const EdgeInsets.symmetric(vertical: 8),
        child: Padding(
          padding: const EdgeInsets.all(14.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
              bagTitle,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
              const SizedBox(height: 6),
              Text(
              description,
              style: const TextStyle(color: Colors.black87),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
              const SizedBox(height: 10),
              _infoRow(Icons.storefront, vendorName),
              _infoRow(Icons.timer, '$pickupStart - $pickupEnd'),
              _infoRow(Icons.inventory, 'Quantity: $quantity'),
              const Spacer(),
              Align(
                alignment: Alignment.bottomRight,
                child: ElevatedButton(
                  onPressed: press,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF2d6a4f),
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  ),
                  child: const Text("View Bag", style: TextStyle(color: Colors.white)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _infoRow(IconData icon, String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2.0),
      child: Row(
        children: [
          Icon(icon, size: 16, color: Colors.grey),
          const SizedBox(width: 6),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(fontSize: 14, color: Colors.grey),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }
}
