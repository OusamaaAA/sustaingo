import 'package:flutter/material.dart';
import '../../components/cards/big/restaurant_info_big_card.dart';
import '../../components/section_title.dart';
import '../../constants.dart';
import '../details/details_screen.dart';
import '../featured/featurred_screen.dart';
import 'components/medium_card_list.dart';
import 'components/promotion_banner.dart';
import '../contactus/contactus.dart';
import '../../../screens/aboutus/aboutus.dart';
import '../../../screens/faq/faqbot.dart';
import '../recipegen/recipegenerator.dart';
import '../../services/api_service.dart';
import '../../../screens/findrestaurants/find_restaurants_screen.dart';
import '../cart/cart.dart';

class HomeScreen extends StatefulWidget {
  final String? deliveryLocation;

  const HomeScreen({super.key, this.deliveryLocation});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  late Future<List<dynamic>> _vendors;
  int _cartItemCount = 0;

  @override
  void initState() {
    super.initState();
    _vendors = ApiService().fetchVendors();
    Future.delayed(const Duration(seconds: 2), () {
      setState(() {
        _cartItemCount = 3;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        key: _scaffoldKey,
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.menu, color: Colors.white),
            onPressed: () => _scaffoldKey.currentState?.openDrawer(),
            iconSize: 24,
          ),
          title: InkWell(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const FindRestaurantsScreen()),
              );
            },
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start, // Align text to the left
              children: [
                Text(
                  "Delivery in".toUpperCase(),
                  style: Theme.of(context)
                      .textTheme
                      .bodySmall!
                      .copyWith(color: Colors.white70), // Softer color
                ),
                Text(
                  widget.deliveryLocation ?? "Beirut",
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w500), // Slightly bolder location
                )
              ],
            ),
          ),
          backgroundColor: const Color(0xFF2d6a4f),
          elevation: 4,
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(bottom: Radius.circular(20)),
          ),
          actions: [
            // Cart Button - Icon only with badge
            Padding(
              padding: const EdgeInsets.only(left: 6.0, right: 12.0),
              child: Stack(
                alignment: Alignment.topRight,
                children: [
                  IconButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => const CartScreen()),
                      );
                    },
                    icon: const Icon(Icons.shopping_cart_outlined, color: Colors.white, size: 24),
                    padding: const EdgeInsets.all(8),
                    style: IconButton.styleFrom(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                  ),
                  if (_cartItemCount > 0)
                    Positioned(
                      right: 0,
                      top: 0,
                      child: Container(
                        padding: const EdgeInsets.all(2),
                        decoration: BoxDecoration(
                          color: Colors.redAccent, // A slightly different red
                          borderRadius: BorderRadius.circular(10),
                        ),
                        constraints: const BoxConstraints(minWidth: 16, minHeight: 16),
                        child: Text(
                          '$_cartItemCount',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ],
          bottom: const TabBar(
            tabs: [
              Tab(text: 'Restaurants'),
              Tab(text: 'Recipe Generator'),
            ],
            labelColor: Colors.white, // Sets the color of the selected tab label
            unselectedLabelColor: Colors.white, //optional: sets the color of the unselected tab labels
            indicatorColor: Colors.white,
          ),
        ),
        drawer: Drawer(
          backgroundColor: Colors.white,
          child: ListView(
            padding: EdgeInsets.zero,
            children: [
              UserAccountsDrawerHeader(
                decoration: const BoxDecoration(color: Color(0xFF2d6a4f)),
                accountName: const Text(
                  'SustainGo',
                  style: TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold),
                ),
                accountEmail: const Text(
                  'Save Food, Save Money',
                  style: TextStyle(color: Colors.white70, fontStyle: FontStyle.italic),
                ),
                currentAccountPicture: const CircleAvatar(
                  backgroundColor: Colors.white70,
                  child: Icon(Icons.restaurant_outlined, size: 40, color: Color(0xFF2d6a4f)),
                ),
              ),
              ListTile(
                leading: const Icon(Icons.question_answer_outlined),
                title: const Text('FAQ Bot'),
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const FAQBotScreen())),
              ),
              ListTile(
                leading: const Icon(Icons.chat_outlined),
                title: const Text('Contact Us'),
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ContactUsScreen())),
              ),
              ListTile(
                leading: const Icon(Icons.info_outline),
                title: const Text('About Us'),
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AboutUsScreen())),
              ),
              const Divider(color: Colors.grey),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            // 🥡 Restaurant List Tab
            SafeArea(
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: defaultPadding),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: defaultPadding),
                      child: AspectRatio(
                        aspectRatio: 3 / 1.5,
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(20),
                          child: Image.asset(
                            "assets/images/sloganbig.PNG",
                            fit: BoxFit.cover,
                            width: double.infinity,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: defaultPadding * 2),
                    SectionTitle(
                      title: "New on SustainGO",
                      press: () => Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => const FeaturedScreen()),
                      ),
                    ),
                    const SizedBox(height: defaultPadding),
                    const MediumCardList(),
                    const SizedBox(height: 20),
                    const PromotionBanner(),
                    const SizedBox(height: 20),
                    const SizedBox(height: 16),
                    const SizedBox(height: 20),
                    SectionTitle(title: "All Restaurants", press: () {}),
                    const SizedBox(height: 16),
                    FutureBuilder<List<dynamic>>(
                      future: _vendors,
                      builder: (context, snapshot) {
                        if (snapshot.connectionState == ConnectionState.waiting) {
                          return const Center(child: CircularProgressIndicator());
                        } else if (snapshot.hasError) {
                          return Padding(
                            padding: const EdgeInsets.all(16),
                            child: Text("Error: ${snapshot.error}"),
                          );
                        } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                          return const Padding(
                            padding: EdgeInsets.all(16),
                            child: Text("No vendors available."),
                          );
                        }

                        return Column(
                          children: snapshot.data!.map((vendor) {
                            final String logo = vendor['logo'] ?? '';
                            final String imageUrl = logo.startsWith('http')
                                ? logo
                                : logo.isNotEmpty
                                ? 'https://res.cloudinary.com/di5srbmpg/$logo'
                                : 'https://via.placeholder.com/300x200.png?text=No+Image';

                            return Padding(
                              padding: const EdgeInsets.fromLTRB(defaultPadding, 0, defaultPadding, defaultPadding),
                              child: RestaurantInfoBigCard(
                                images: [imageUrl],
                                name: vendor['name'],
                                rating: 4.3,
                                numOfRating: 200,
                                deliveryTime: vendor['delivery_time_minutes'] ?? 25,
                                foodType: const ["Mystery Bag", "Rescue", "Discount"],
                                press: () => Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => DetailsScreen(vendor: vendor),
                                  ),
                                ),
                              ),
                            );
                          }).toList(),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ),
            // 🧠 Recipe Generator Tab
            const RecipeGeneratorScreen(),
          ],//
        ),
      ),
    );
  }
}