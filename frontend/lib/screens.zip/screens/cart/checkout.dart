import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'cart.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';

class CheckoutScreen extends StatefulWidget {
  final List<CartItem> cartItems;
  final double totalPrice;

  const CheckoutScreen({super.key, required this.cartItems, required this.totalPrice});

  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

enum PaymentMethod { creditCard, cashOnDelivery }

class _CheckoutScreenState extends State<CheckoutScreen> {
  final _formKey = GlobalKey<FormState>();
  final _addressController = TextEditingController();
  final _phoneController = TextEditingController();
  PaymentMethod? _paymentMethod = PaymentMethod.cashOnDelivery;
  String? _selectedCardType;
  final _cardNumberController = TextEditingController();
  final _expiryDateController = TextEditingController();
  final _cvvController = TextEditingController();
  final _cardHolderNameController = TextEditingController();
  double _deliveryFee = 0.0;

  MaskTextInputFormatter _expiryDateFormatter = MaskTextInputFormatter(mask: 'MM/YY', filter: {"M": RegExp(r'[0-1]'), "Y": RegExp(r'[0-9]')});
  MaskTextInputFormatter _cvvFormatter = MaskTextInputFormatter(mask: '###', filter: {"#": RegExp(r'[0-9]')});
  final MaskTextInputFormatter _cardNumberFormatter = MaskTextInputFormatter(mask: '####-####-####-####', filter: {"#": RegExp(r'[0-9]')});

  @override
  void initState() {
    super.initState();
    _calculateDeliveryFee();
  }

  void _calculateDeliveryFee() {
    setState(() {
      _deliveryFee = widget.totalPrice < 20 ? 1.49 : 0.0; // Adjusted delivery fee threshold
    });
  }

  double get _finalTotalPrice => widget.totalPrice + _deliveryFee;

  @override
  void dispose() {
    _addressController.dispose();
    _phoneController.dispose();
    _cardNumberController.dispose();
    _expiryDateController.dispose();
    _cvvController.dispose();
    _cardHolderNameController.dispose();
    super.dispose();
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10.0),
      child: Text(
        title,
        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500, color: Colors.black87),
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String labelText,
    TextInputType? keyboardType,
    String? Function(String?)? validator,
    List<TextInputFormatter>? inputFormatters,
    Widget? prefixIcon,
  }) {
    return TextFormField(
      controller: controller,
      keyboardType: keyboardType,
      decoration: InputDecoration(
        labelText: labelText,
        border: const OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(8))),
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        prefixIcon: prefixIcon,
      ),
      validator: validator,
      inputFormatters: inputFormatters,
    );
  }

  Widget _buildPaymentOptions() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionTitle('Payment Method'),
        ListTile(
          title: const Text('Cash on Delivery', style: TextStyle(fontSize: 14)),
          leading: Radio<PaymentMethod>(
            value: PaymentMethod.cashOnDelivery,
            groupValue: _paymentMethod,
            onChanged: (PaymentMethod? value) {
              setState(() {
                _paymentMethod = value;
              });
            },
          ),
        ),
        ListTile(
          title: const Text('Credit Card', style: TextStyle(fontSize: 14)),
          leading: Radio<PaymentMethod>(
            value: PaymentMethod.creditCard,
            groupValue: _paymentMethod,
            onChanged: (PaymentMethod? value) {
              setState(() {
                _paymentMethod = value;
              });
            },
          ),
        ),
        if (_paymentMethod == PaymentMethod.creditCard)
          Padding(
            padding: const EdgeInsets.only(left: 16.0, top: 8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildSectionTitle('Credit Card Details'),
                _buildCardTypeSelector(), // Card Type selector is now first
                const SizedBox(height: 10),
                _buildTextField( // Cardholder Name is now second
                  controller: _cardHolderNameController,
                  labelText: 'Cardholder Name',
                  validator: (value) {
                    if (_paymentMethod == PaymentMethod.creditCard && (value == null || value.isEmpty)) {
                      return 'Please enter the name on the card';
                    }
                    if (value != null && !RegExp(r'^[a-zA-Z\s]+$').hasMatch(value)) {
                      return 'Cardholder name can only contain letters and spaces';
                    }
                    return null;
                  },
                  prefixIcon: const Icon(Icons.person_outline),
                  inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[a-zA-Z\s]'))],
                ),
                const SizedBox(height: 10),
                _buildTextField(
                  controller: _cardNumberController,
                  labelText: 'Card Number',
                  keyboardType: TextInputType.number,
                  inputFormatters: [_cardNumberFormatter],
                  validator: (value) {
                    if (_paymentMethod == PaymentMethod.creditCard && (value == null || value.isEmpty)) {
                      return 'Please enter your card number';
                    }
                    final cleanedCardNumber = value?.replaceAll('-', '') ?? '';
                    if (cleanedCardNumber.length != 16) {
                      return 'Card number must be 16 digits';
                    }
                    if (_selectedCardType != null && value != null && value.isNotEmpty) {
                      if (!isValidCreditCard(cleanedCardNumber)) {
                        return 'Please enter a valid card number';
                      }
                    }
                    return null;
                  },
                  prefixIcon: const Icon(Icons.credit_card_outlined),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: _buildTextField(
                        controller: _expiryDateController,
                        labelText: 'Expiry (MM/YY)',
                        keyboardType: TextInputType.datetime,
                        inputFormatters: [_expiryDateFormatter],
                        validator: (value) {
                          if (_paymentMethod == PaymentMethod.creditCard && (value == null || value.isEmpty)) {
                            return 'Please enter the expiry date';
                          }
                          if (value != null && value.isNotEmpty && !isValidExpiryDate(value)) {
                            return 'Please enter a valid expiry date (MM/YY)';
                          }
                          final parts = value?.split('/') ?? [];
                          if (parts.length == 2) {
                            final month = int.tryParse(parts[0]);
                            final year = int.tryParse('20${parts[1]}');
                            final now = DateTime.now();
                            final currentYear = now.year;
                            final currentMonth = now.month;

                            if (year != null && month != null) {
                              if (year < currentYear || (year == currentYear && month < currentMonth)) {
                                return 'Expiry date cannot be in the past';
                              }
                            }
                          }
                          return null;
                        },
                        prefixIcon: const Icon(Icons.calendar_today_outlined),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _buildTextField(
                        controller: _cvvController,
                        labelText: 'CVV',
                        keyboardType: TextInputType.number,
                        inputFormatters: [_cvvFormatter],
                        validator: (value) {
                          if (_paymentMethod == PaymentMethod.creditCard && (value == null || value.isEmpty)) {
                            return 'Please enter the CVV';
                          }
                          if (value != null && value.isNotEmpty) {
                            if ((_selectedCardType == 'American Express' && value.length != 4) ||
                                (['Visa', 'Mastercard', 'Discover'].contains(_selectedCardType) && value.length != 3)) {
                              return 'Please enter a valid CVV';
                            }
                          }
                          return null;
                        },
                        prefixIcon: const Icon(Icons.lock_outline),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
      ],
    );
  }

  Widget _buildCardTypeSelector() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Card Type', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500, color: Colors.black87)),
        Wrap(
          spacing: 8.0, // Space between image-text pairs horizontally
          runSpacing: 8.0, // Space between lines if they wrap
          children: <Widget>[
            _buildCardImageSelector('Visa'),
            _buildCardImageSelector('Mastercard'),
            _buildCardImageSelector('American Express'),
            _buildCardImageSelector('Discover'),
          ],
        ),
        if (_selectedCardType == null)
          Padding(
            padding: const EdgeInsets.only(top: 8.0),
            child: Text(
              'Please select a card type',
              style: TextStyle(color: Colors.red[700], fontSize: 12),
            ),
          ),
      ],
    );
  }

  Widget _buildCardImageSelector(String cardType) {
    return GestureDetector(
      onTap: () {
        setState(() {
          _selectedCardType = cardType;
          if (cardType == 'American Express') {
            _cvvFormatter = MaskTextInputFormatter(mask: '####', filter: {"#": RegExp(r'[0-9]')});
          } else {
            _cvvFormatter = MaskTextInputFormatter(mask: '###', filter: {"#": RegExp(r'[0-9]')});
          }
          _cvvController.clear();
        });
      },
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              border: Border.all(
                color: _selectedCardType == cardType ? Colors.green : Colors.transparent,
                width: 2,
              ),
              borderRadius: BorderRadius.circular(8),
            ),
            child: _getCardIcon(cardType),
          ),
          const SizedBox(width: 4),
          Text(cardType),
        ],
      ),
    );
  }

  Widget _getCardIcon(String cardType) {
    switch (cardType) {
      case 'Visa':
        return SvgPicture.asset('assets/images/visa.svg', height: 30);
      case 'Mastercard':
        return SvgPicture.asset('assets/images/mastercard.svg', height: 30);
      case 'American Express':
        return SvgPicture.asset('assets/images/amex.svg', height: 30);
      case 'Discover':
        return SvgPicture.asset('assets/images/discover.svg', height: 30);
      default:
        return const SizedBox(width: 30);
    }
  }

  bool isValidCreditCard(String cardNumber) {
    String cleanedCardNumber = cardNumber.replaceAll(RegExp(r'[^0-9]'), '');
    if (cleanedCardNumber.isEmpty) {
      return false;
    }
    int sum = 0;
    bool alternate = false;
    for (int i = cleanedCardNumber.length - 1; i >= 0; i--) {
      int digit = int.parse(cleanedCardNumber[i]);
      if (alternate) {
        digit *= 2;
        if (digit > 9) {
          digit -= 9;
        }
      }
      sum += digit;
      alternate = !alternate;
    }
    return (sum % 10 == 0);
  }

  bool isValidExpiryDate(String expiryDate) {
    final parts = expiryDate.split('/');
    if (parts.length != 2 || parts[0].length != 2 || parts[1].length != 2) {
      return false;
    }
    final month = int.tryParse(parts[0]);
    final year = int.tryParse('20${parts[1]}');
    if (month == null || year == null || month < 1 || month > 12 || year < DateTime.now().year) {
      return false;
    }
    final now = DateTime.now();
    final currentYear = now.year;
    final currentMonth = now.month;
    if (year == currentYear && month < currentMonth) {
      return false;
    }
    return true;
  }

  Widget _buildOrderSummary() {
    return Container(
      padding: const EdgeInsets.all(16.0),
      decoration: BoxDecoration(
        color: Colors.grey[100],
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSectionTitle('Order Summary'),
          ListView.separated(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: widget.cartItems.length,
            separatorBuilder: (context, index) => const Divider(height: 6),
            itemBuilder: (context, index) {
              final item = widget.cartItems[index];
              return Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('${item.name} x ${item.quantity}', style: const TextStyle(fontSize: 14)),
                  Text('\$${(item.price * item.quantity).toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.w500)),
                ],
              );
            },
          ),
          const SizedBox(height: 12),
          const Divider(thickness: 1),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Subtotal:', style: TextStyle(fontSize: 14)),
                Text('\$${widget.totalPrice.toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.w500)),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Delivery:', style: TextStyle(fontSize: 14)),
                Text(widget.totalPrice < 20 ? '\$${_deliveryFee.toStringAsFixed(2)}' : 'FREE',
                    style: TextStyle(fontWeight: FontWeight.w500, color: Colors.green[600])),
              ],
            ),
          ),
          const Divider(thickness: 1),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 12.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Total:', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                Text('\$${_finalTotalPrice.toStringAsFixed(2)}',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.green[700])),
              ],
            ),
          ),
        ],
      ),
    );
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text('Checkout', style: TextStyle(color: Colors.white)),
          backgroundColor: const Color(0xFF2d6a4f),
          elevation: 1,
          iconTheme: const IconThemeData(color: Colors.white),
        ),
        body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
    child: Form(
    key: _formKey,
    child: Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
    _buildSectionTitle('Delivery Details'),
    _buildTextField(
    controller: _addressController,
    labelText: 'Delivery Address',
    validator: (value) {
    if (value == null || value.isEmpty) {
    return 'Please enter your delivery address';
    }
    return null;
    },
    prefixIcon: const Icon(Icons.home_outlined),
    ),
    const SizedBox(height: 12),
      _buildTextField(
        controller: _phoneController,
        labelText: 'Phone Number',
        keyboardType: TextInputType.phone,
        validator: (value) {
          if (value == null || value.isEmpty) {
            return 'Please enter your phone number';
          }
          // You can add more sophisticated phone number validation here if needed
          return null;
        },
        prefixIcon: const Icon(Icons.phone_outlined),
        inputFormatters: [
          FilteringTextInputFormatter.digitsOnly, // Only allows digits
          LengthLimitingTextInputFormatter(15), // Example max length (adjust as needed)
        ],
      ),
    const SizedBox(height: 20),
    _buildPaymentOptions(),
    const SizedBox(height: 20),
    _buildOrderSummary(),
    const SizedBox(height: 32),
      SizedBox(
        width: double.infinity,
        child: ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF2d6a4f),
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 16),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          onPressed: () {
            if (_formKey.currentState!.validate()) {
              if (_paymentMethod == PaymentMethod.creditCard) {
                final cleanedCardNumber = _cardNumberController.text.replaceAll('-', '');
                if (_selectedCardType != null &&
                    cleanedCardNumber.length == 16 &&
                    _expiryDateController.text.isNotEmpty &&
                    _cvvController.text.isNotEmpty &&
                    ((_selectedCardType == 'American Express' && _cvvController.text.length == 4) ||
                        (['Visa', 'Mastercard', 'Discover'].contains(_selectedCardType) &&
                            _cvvController.text.length == 3)) &&
                    _cardHolderNameController.text.isNotEmpty) {
                  _showOrderConfirmationDialog();
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Please fill in all credit card details correctly')),
                  );
                }
              } else if (_paymentMethod == PaymentMethod.cashOnDelivery) {
                _showOrderConfirmationDialog();
              }
            } else {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Please fill in all required delivery details')),
              );
            }
          },
          child: const Text('Place Order'),
        ),
      ),
    ],
    ),
    ),
        ),
    );
  }

  void _showOrderConfirmationDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Order Confirmation'),
          content: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('Delivery Address: ${_addressController.text}'),
                Text('Phone Number: ${_phoneController.text}'),
                Text(
                  'Payment Method: ${_paymentMethod == PaymentMethod.creditCard ? 'Credit Card ($_selectedCardType)' : 'Cash on Delivery'}',
                ),
                if (_paymentMethod == PaymentMethod.creditCard) ...[
                  Text('Name on card: ${_cardHolderNameController.text}'),
                  Text(
                    'Card Number: ****-****-****-${_cardNumberController.text.substring(_cardNumberController.text.length - 4)}',
                  ),
                  Text('Expiry Date: ${_expiryDateController.text}'),
                  Text('Security Code: ${_cvvController.text}'),
                ],
                Text('Delivery Fee: ${widget.totalPrice < 20 ? '\$${_deliveryFee.toStringAsFixed(2)}' : 'FREE'}'),
                const SizedBox(height: 16),
                const Divider(),
                const SizedBox(height: 16),
                Text(
                  'Total Amount: \$${_finalTotalPrice.toStringAsFixed(2)}',
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                ),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.of(context).pop();
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Order placed successfully!')),
                );
                // In a real app, you would clear the cart and navigate to an order confirmation screen.
              },
              child: const Text('Confirm Order', style: TextStyle(fontWeight: FontWeight.bold)),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('Cancel'),
            ),
          ],
        );
      },
    );
  }
}