import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'ngo_profile_screen.dart';
import 'request_items.dart';
import 'restaurant_ngo_cards.dart';
import '../../components/section_title.dart';
import '../../constants.dart';
import '../../../screens/auth/sign_in_screen.dart';

class NGOHomeScreen extends StatefulWidget {
  const NGOHomeScreen({super.key});

  @override
  State<NGOHomeScreen> createState() => _NgoHomeScreenState();
}

class _NgoHomeScreenState extends State<NGOHomeScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  Map<String, dynamic> _ngoSummary = {
    'total_donations': 0,
    'total_items_rescued': 0,
  };

  List<dynamic> _donationBags = [];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _handleSession());
  }

  Future<void> _handleSession() async {
    final ok = await _refreshToken();
    if (!ok) {
      _redirectToLogin();
      return;
    }
    fetchDashboardSummary();
    fetchDonationBags();
  }

  Future<bool> _refreshToken() async {
    final prefs = await SharedPreferences.getInstance();
    final refresh = prefs.getString('refresh');
    if (refresh == null) return false;

    final response = await http.post(
      Uri.parse('https://sustaingobackend.onrender.com/api/token/refresh/'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'refresh': refresh}),
    );
    print("Attempting to refresh token...");
    print("Stored refresh: $refresh");
    print("Response status: ${response.statusCode}");
    print("Response body: ${response.body}");

    if (response.statusCode == 200) {
      final newAccess = jsonDecode(response.body)['access'];
      await prefs.setString('token', newAccess); // ✅ Match key

      return true;
    }
    await prefs.remove('auth_token');
    await prefs.remove('refresh');
    return false;
  }

  void _redirectToLogin() {
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const SignInScreen()),
          (route) => false,
    );
  }

  Future<void> fetchDashboardSummary() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('auth_token');

    final response = await http.get(
      Uri.parse('https://sustaingobackend.onrender.com/api/get_ngo_dashboard_summary/'),
      headers: {
        "Authorization": "Bearer $token",
        "Content-Type": "application/json",
      },
    );
    if (response.statusCode == 200) {
      setState(() {
        _ngoSummary = json.decode(response.body);
      });
    }
  }

  Future<void> fetchDonationBags() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('auth_token');

    final response = await http.get(
      Uri.parse('https://sustaingobackend.onrender.com/api/get_donation_bags/'),
      headers: {
        "Authorization": "Bearer $token",
        "Content-Type": "application/json",
      },
    );

    if (response.statusCode == 200) {
      setState(() {
        _donationBags = json.decode(response.body);
      });
    }
  }

  void _showAvailableItems(BuildContext context, Map<String, dynamic> bag) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (BuildContext bc) {
        return RequestItemsBottomSheet(
          availableItems: [
            {"name": bag['hidden_contents'], "quantity": bag['quantity_available']}
          ],
          vendorName: bag['vendor_name'],
          pickupStart: bag['pickup_start'],
          pickupEnd: bag['pickup_end'],
          onReserve: () async {
            final prefs = await SharedPreferences.getInstance();
            final token = prefs.getString('auth_token');

            final response = await http.post(
              Uri.parse('https://sustaingobackend.onrender.com/api/bags/${bag['id']}/reserve/'),
              headers: {
                'Authorization': 'Bearer $token',
                'Content-Type': 'application/json',
              },
            );

            Navigator.pop(context);

            if (response.statusCode == 201) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Reservation successful')),
              );
            } else {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Reservation failed')),
              );
            }
          },
        );
      },
    );
  }

  Widget _buildDonationStatsCard() {
    final int numberOfDonations = _ngoSummary['total_donations'] ?? 0;
    final int numberOfFoodItems = _ngoSummary['total_items_rescued'] ?? 0;

    return Card(
      elevation: 2,
      margin: const EdgeInsets.symmetric(vertical: defaultPadding / 2),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: Padding(
        padding: const EdgeInsets.all(defaultPadding),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Your Impact Today",
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: defaultPadding / 2),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Column(
                  children: [
                    Text(
                      "$numberOfDonations",
                      style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Color(0xFF2d6a4f)),
                    ),
                    const Text("Donations Collected", style: TextStyle(color: Colors.grey)),
                  ],
                ),
                Container(height: 30, child: const VerticalDivider(color: Colors.grey)),
                Column(
                  children: [
                    Text(
                      "$numberOfFoodItems+",
                      style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Color(0xFFE67E22)),
                    ),
                    const Text("Food Items Rescued", style: TextStyle(color: Colors.grey)),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        title: const Text(
          'NGO Dashboard',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        backgroundColor: const Color(0xFF2d6a4f),
        elevation: 4,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(bottom: Radius.circular(20)),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.account_circle, size: 30, color: Colors.white),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const NGOProfileScreen()),
              );
            },
          ),
          const SizedBox(width: defaultPadding / 2),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(defaultPadding),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SectionTitle(title: "Welcome, NGO!", press: () {}),
              const SizedBox(height: defaultPadding),
              Container(
                width: double.infinity,
                height: 200.0,
                color: Colors.amber[100],
                child: Center(
                  child: Image.asset(
                    'assets/images/ngoslog.png',
                    fit: BoxFit.cover,
                    width: double.infinity,
                    height: double.infinity,
                  ),
                ),
              ),
              const SizedBox(height: defaultPadding),
              _buildDonationStatsCard(),
              const SizedBox(height: defaultPadding),
              SectionTitle(title: "Donations Ready for Pickup", press: () {}),
              const SizedBox(height: defaultPadding / 2),
              Wrap(
                spacing: defaultPadding,
                runSpacing: defaultPadding,
                children: _donationBags.map((bag) {
                  return SizedBox(
                    width: (MediaQuery.of(context).size.width - 3 * defaultPadding) / 2,
                    child: RestaurantInfoBigCardNgo(
                      bagTitle: bag['title'] ?? 'Untitled Bag',
                      description: bag['description'] ?? 'No description',
                      vendorName: bag['vendor_name'] ?? 'Unknown Vendor',
                      quantity: bag['quantity_available'] ?? 0,
                      pickupStart: bag['pickup_start'] ?? 'N/A',
                      pickupEnd: bag['pickup_end'] ?? 'N/A',
                      press: () => _showAvailableItems(context, bag),
                    ),
                  );
                }).toList(),
              ),
              const SizedBox(height: defaultPadding * 2),
            ],
          ),
        ),
      ),
    );
  }
}