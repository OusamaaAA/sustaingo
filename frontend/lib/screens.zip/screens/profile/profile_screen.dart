import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../contactus/contactus.dart';
import '../../../screens/aboutus/aboutus.dart';
import '../../../screens/faq/faqbot.dart';
import '../../../constants.dart';
import '../auth/sign_in_screen.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  String? fullName;
  String? email;
  String? phone;
  String? location;
  final _formKey = GlobalKey<FormState>();
  final _fullNameController = TextEditingController();
  final _emailController = TextEditingController();
  final _phoneController = TextEditingController();
  final _locationController = TextEditingController();
  bool _isEditing = false;

  @override
  void initState() {
    super.initState();
    _loadUserProfile();
  }

  Future<void> _loadUserProfile() async {
  final prefs = await SharedPreferences.getInstance();
  String? token = prefs.getString('auth_token');
  String? refreshToken = prefs.getString('refresh_token');

  if (token == null || refreshToken == null) {
    print("No valid tokens found. Redirecting to login...");
    return;
  }

  final response = await http.get(
    Uri.parse('https://sustaingobackend.onrender.com/api/profile/'),
    headers: {
      'Authorization': 'Bearer $token',
    },
  );

  if (response.statusCode == 200) {
    final data = json.decode(response.body);
    setState(() {
      fullName = data['full_name'];
      email = data['email'];
      phone = data['phone_number'];
      location = data['region'];

      _fullNameController.text = fullName ?? '';
      _emailController.text = email ?? '';
      _phoneController.text = phone ?? '';
      _locationController.text = location ?? '';
    });
  } else if (response.statusCode == 401) {
    // Try refreshing the token
    final refreshResponse = await http.post(
      Uri.parse('https://sustaingobackend.onrender.com/api/token/refresh/'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'refresh': refreshToken}),
    );

    if (refreshResponse.statusCode == 200) {
      final newAccessToken = jsonDecode(refreshResponse.body)['access'];
      await prefs.setString('auth_token', newAccessToken);
      return _loadUserProfile(); // Retry with new token
    } else {
      print('Session expired. Please log in again.');
    }
  } else {
    print('Failed to load user profile: ${response.body}');
  }
}


  Future<void> _updateUserProfile() async {
    if (_formKey.currentState!.validate()) {
      // Use the form key
      final prefs = await SharedPreferences.getInstance();
      final token = prefs.getString('token');

      final response = await http.patch(
        Uri.parse('https://sustaingobackend.onrender.com/api/profile/'),
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'full_name': _fullNameController.text,
          'email': _emailController.text,
          'phone_number': _phoneController.text,
          'region': _locationController.text,
        }),
      );

      if (response.statusCode == 200) {
        setState(() {
          fullName = _fullNameController.text;
          email = _emailController.text;
          phone = _phoneController.text;
          location = _locationController.text;
          _isEditing = false; // Exit editing mode on success
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Profile updated successfully!')),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Failed to update profile.')),
        );
      }
    }
  }

  void _logout(BuildContext context) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('token');

    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (context) => const SignInScreen()),
          (route) => false,
    );

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Logged out successfully!')),
    );
  }

  @override
  void dispose() {
    _fullNameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _locationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: Builder(
          builder: (BuildContext context) {
            return IconButton(
              icon: const Icon(Icons.menu, color: Colors.white),
              onPressed: () {
                Scaffold.of(context).openDrawer();
              },
            );
          },
        ),
        automaticallyImplyLeading: false,
        title: const Text(
          "Account Settings",
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
        backgroundColor: const Color(0xFF2d6a4f),
        elevation: 4,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(20),
          ),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      drawer: Drawer(
        backgroundColor: Colors.white,
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            UserAccountsDrawerHeader(
              decoration: const BoxDecoration(color: Color(0xFF2d6a4f)),
              accountName: const Text(
                'SustainGo',
                style: TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold),
              ),
              accountEmail: const Text(
                'Save Food, Save Money',
                style: TextStyle(color: Colors.white70, fontStyle: FontStyle.italic),
              ),
              currentAccountPicture: const CircleAvatar(
                backgroundColor: Colors.white70,
                child: Icon(Icons.restaurant_outlined, size: 40, color: Color(0xFF2d6a4f)),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.question_answer_outlined),
              title: const Text('FAQ Bot'),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const FAQBotScreen())),
            ),
            ListTile(
              leading: const Icon(Icons.chat_outlined),
              title: const Text('Contact Us'),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ContactUsScreen())),
            ),
            ListTile(
              leading: const Icon(Icons.info_outline),
              title: const Text('About Us'),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AboutUsScreen())),
            ),
            const Divider(color: Colors.grey),
          ],
        ),
      ),
      body: Form(
        // Wrap the entire body in a Form widget
        key: _formKey,
        child: Body(
          isEditing: _isEditing,
          fullName: fullName,
          email: email,
          phone: phone,
          location: location,
          fullNameController: _fullNameController,
          emailController: _emailController,
          phoneController: _phoneController,
          locationController: _locationController,
          onLogout: () => _logout(context),
          onUpdate: _updateUserProfile,
          onEditPressed: () {
            setState(() {
              _isEditing = !_isEditing;
            });
          },
        ),
      ),
    );
  }
}

class Body extends StatelessWidget {
  const Body({
    super.key,
    this.onLogout,
    this.fullName,
    this.email,
    this.phone,
    this.location,
    required this.fullNameController,
    required this.emailController,
    required this.phoneController,
    required this.locationController,
    required this.onUpdate,
    this.isEditing = false,
    this.onEditPressed,
  });

  final VoidCallback? onLogout;
  final String? fullName;
  final String? email;
  final String? phone;
  final String? location;
  final TextEditingController fullNameController;
  final TextEditingController emailController;
  final TextEditingController phoneController;
  final TextEditingController locationController;
  final VoidCallback onUpdate;
  final bool isEditing;
  final VoidCallback? onEditPressed;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: defaultPadding),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: defaultPadding * 1.5),
            Center(
              child: Column(
                children: <Widget>[
                  const SizedBox(height: defaultPadding),
                  Text(
                    isEditing ? 'Editing Profile' : fullName ?? 'Loading...',
                    style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w700),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: defaultPadding),
                ],
              ),
            ),
            const SizedBox(height: defaultPadding),
            ModernProfileTaskCard(
              svgSrc: "assets/icons/profile.svg",
              title: "Full Name",
              subTitle: isEditing ? null : fullName ?? 'No name provided.',
              color: const Color(0xFF60A917),
              press: () {},
              child: isEditing
                  ? TextFormField(
                controller: fullNameController,
                decoration: const InputDecoration(labelText: 'Full Name'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your full name';
                  }
                  return null;
                },
              )
                  : null,
            ),
            const SizedBox(height: defaultPadding / 2),
            ModernProfileTaskCard(
              svgSrc: "assets/icons/phone.svg",
              title: "Phone Number",
              subTitle: isEditing ? null : phone ?? 'No phone number provided.',
              color: const Color(0xFFE67E22),
              press: () {},
              child: isEditing
                  ? TextFormField(
                controller: phoneController,
                decoration: const InputDecoration(labelText: 'Phone Number'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your phone number';
                  }
                  return null;
                },
              )
                  : null,
            ),
            const SizedBox(height: defaultPadding / 2),
            ModernProfileTaskCard(
              svgSrc: "assets/icons/mail.svg",
              title: "Email Address",
              subTitle: isEditing ? null : email ?? '',
              color: const Color(0xFF3498DB),
              press: () {},
              child: isEditing
                  ? TextFormField(
                controller: emailController,
                decoration: const InputDecoration(labelText: 'Email Address'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your email address';
                  }
                  return null;
                },
              )
                  : null,
            ),
            const SizedBox(height: defaultPadding / 2),
            ModernProfileTaskCard(
              svgSrc: "assets/icons/marker.svg",
              title: "Location",
              subTitle: isEditing ? null : location ?? 'No location provided.',
              color: const Color(0xFF9B59B6),
              press: () {},
              child: isEditing
                  ? TextFormField(
                controller: locationController,
                decoration: const InputDecoration(labelText: 'Location'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your location';
                  }
                  return null;
                },
              )
                  : null,
            ),
            const SizedBox(height: defaultPadding * 1.5),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: onEditPressed,
                style: ElevatedButton.styleFrom(
                  backgroundColor:
                  isEditing ? Color(0xFF3498DB) : const Color(0xFF2d6a4f),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  textStyle: const TextStyle(fontSize: 16),
                ),
                child: Text(
                  isEditing ? 'Save Changes' : 'Edit All Information',
                  style: const TextStyle(
                      color: Colors.white, fontWeight: FontWeight.w500),
                ),
              ),
            ),
            const SizedBox(height: defaultPadding / 2),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: onLogout,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFE74C3C),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  textStyle: const TextStyle(fontSize: 16),
                ),
                child: const Text(
                  'Log Out',
                  style: TextStyle(
                      color: Colors.white, fontWeight: FontWeight.w500),
                ),
              ),
            ),
            const SizedBox(height: defaultPadding),
          ],
        ),
      ),
    );
  }
}

class ModernProfileTaskCard extends StatelessWidget {
  const ModernProfileTaskCard({
    super.key,
    this.title,
    this.subTitle,
    this.svgSrc,
    this.press,
    this.color,
    this.child,
  });

  final String? title, subTitle, svgSrc;
  final VoidCallback? press;
  final Color? color;
  final Widget? child;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: defaultPadding / 3),
      child: InkWell(
        borderRadius: BorderRadius.circular(10),
        onTap: press,
        child: Container(
          decoration: BoxDecoration(
            color: color?.withOpacity(0.08) ?? Colors.grey.withOpacity(0.03),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: Colors.grey.shade200, width: 1),
          ),
          padding: const EdgeInsets.all(defaultPadding),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: color?.withOpacity(0.8) ??
                      titleColor.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: SvgPicture.asset(
                  svgSrc!,
                  height: 22,
                  width: 22,
                  colorFilter: ColorFilter.mode(
                    color ?? titleColor,
                    BlendMode.srcIn,
                  ),
                ),
              ),
              const SizedBox(width: defaultPadding),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title!,
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                        color: Colors.grey.shade800,
                      ),
                    ),
                    if (child == null && subTitle != null && subTitle!.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(top: 3.0),
                        child: Text(
                          subTitle!,
                          style: TextStyle(
                              fontSize: 14, color: Colors.grey.shade600),
                        ),
                      ),
                    if (child != null)
                      child!,
                  ],
                ),
              ),
              if (child == null)
                const Icon(
                  Icons.arrow_forward_ios,
                  color: Colors.grey,
                  size: 18,
                ),
            ],
          ),
        ),
      ),
    );
  }
}
