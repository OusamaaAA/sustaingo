import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '../../../entry_point.dart';
import '../../../components/buttons/secondary_button.dart';
import '../../../components/welcome_text.dart';
import '../../../constants.dart';

class FindRestaurantsScreen extends StatefulWidget {
  const FindRestaurantsScreen({super.key});

  @override
  State<FindRestaurantsScreen> createState() => _FindRestaurantsScreenState();
}

class _FindRestaurantsScreenState extends State<FindRestaurantsScreen> {
  String? _enteredAddress = "Tarik Al Jadida, Beirut";

  Future<void> _getCurrentLocation() async {
    print("Simulating getting current location...");
    String currentLocation = "Achrafieh, Beirut"; // Simulate location retrieval
    _navigateToEntryPoint(context, currentLocation);
  }

  Future<void> _findRestaurantsByAddress() async {
    print("Attempting to navigate with entered address: $_enteredAddress");
    if (_enteredAddress != null && _enteredAddress!.isNotEmpty) {
      _navigateToEntryPoint(context, _enteredAddress);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter an address.')),
      );
    }
  }

  void _navigateToEntryPoint(BuildContext context, String? location) {
    print("Navigating to EntryPoint with location: $location");
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => EntryPoint(
          initialIndex: 0,
          initialDeliveryLocation: location,
        ),
      ),
    );
    print("Navigation to EntryPoint complete.");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.close),
          onPressed: () {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) => const EntryPoint(),
              ),
            );
          },
        ),
        title: const Text("Find Restaurants", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 20)),
        backgroundColor: const Color(0xFF2d6a4f),
        elevation: 4,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.vertical(bottom: Radius.circular(20))),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: defaultPadding),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const WelcomeText(
                title: "Find restaurants near you ",
                text: "Please enter your location or allow access to \nyour location to find restaurants near you.",
              ),
              SecondaryButton(
                press: _getCurrentLocation,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SvgPicture.asset("assets/icons/location.svg", height: 24, colorFilter: const ColorFilter.mode(primaryColor, BlendMode.srcIn)),
                    const SizedBox(width: 8),
                    Text("Use current location", style: Theme.of(context).textTheme.bodyMedium!.copyWith(color: primaryColor))
                  ],
                ),
              ),
              const SizedBox(height: defaultPadding),
              Form(
                child: Column(
                  children: [
                    TextFormField(
                      initialValue: _enteredAddress,
                      onChanged: (value) {
                        setState(() {
                          _enteredAddress = value;
                        });
                      },
                      style: Theme.of(context).textTheme.bodyMedium!.copyWith(color: titleColor),
                      cursorColor: primaryColor,
                      decoration: InputDecoration(
                        prefixIcon: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: SvgPicture.asset("assets/icons/marker.svg", colorFilter: const ColorFilter.mode(bodyTextColor, BlendMode.srcIn)),
                        ),
                        hintText: "Enter a new address",
                        contentPadding: kTextFieldPadding,
                      ),
                    ),
                    const SizedBox(height: defaultPadding),
                    ElevatedButton(
                      onPressed: _findRestaurantsByAddress,
                      child: const Text("Continue"),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: defaultPadding),
            ],
          ),
        ),
      ),
    );
  }
}