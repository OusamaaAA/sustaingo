import 'dart:convert'; // For jsonDecode
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:http/http.dart' as http; // For http requests
import 'package:shared_preferences/shared_preferences.dart'; // For SharedPreferences
import '../../services/api_service.dart';
import '../../components/empty_state.dart';
import '../../constants.dart';

class ViewAllReviewsScreen extends StatefulWidget {
  final dynamic vendorId;
  final String vendorName;

  const ViewAllReviewsScreen({
    super.key,
    required this.vendorId,
    required this.vendorName,
  });

  @override
  State<ViewAllReviewsScreen> createState() => _ViewAllReviewsScreenState();
}

class _ViewAllReviewsScreenState extends State<ViewAllReviewsScreen> {
  late Future<List<dynamic>> _reviews;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _loadReviews();
  }

  Future<void> _loadReviews() async {
    setState(() => _isLoading = true);
    try {
      _reviews = _fetchVendorReviewsWithId(widget.vendorId);
      await _reviews;
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  Future<List<dynamic>> _fetchVendorReviewsWithId(dynamic vendorId) async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('token');

    // Convert vendorId to string if it's not already
    final vendorIdStr = vendorId.toString();

    final response = await http.get(
      Uri.parse('${ApiService().baseUrl}/vendors/$vendorIdStr/reviews/'),
      headers: {
        'Authorization': 'Bearer $token',
      },
    );

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception('Failed to load vendor reviews');
    }
  }

  Future<void> _refreshReviews() async {
    await _loadReviews();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: Row(
          children: [
            const Icon(Icons.star, color: Colors.white),
            const SizedBox(width: 8.0),
            Text(
              "${widget.vendorName} Reviews",
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 20,
              ),
            ),
          ],
        ),
        centerTitle: true,
        backgroundColor: const Color(0xFF2d6a4f),
        elevation: 4,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(20),
          ),
        ),
      ),
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: _refreshReviews,
          child: _isLoading
              ? const Center(child: CircularProgressIndicator())
              : FutureBuilder<List<dynamic>>(
            future: _reviews,
            builder: (context, snapshot) {
              if (snapshot.hasError) {
                return Center(
                  child: Text(
                    'Error loading reviews: ${snapshot.error}',
                    style: const TextStyle(color: Colors.red),
                  ),
                );
              }

              if (!snapshot.hasData || snapshot.data!.isEmpty) {
                return const EmptyState(
                  title: "No Reviews Yet",
                  description: "This vendor hasn't received any reviews yet.",
                  icon: Icons.star_border,
                );
              }

              final reviews = snapshot.data!;
              return ListView.builder(
                padding: const EdgeInsets.all(defaultPadding),
                itemCount: reviews.length,
                itemBuilder: (context, index) {
                  final review = reviews[index];
                  return Card(
                    elevation: 3,
                    margin: const EdgeInsets.only(bottom: defaultPadding),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(defaultPadding),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              CircleAvatar(
                                backgroundColor: const Color(0xFF2d6a4f),
                                child: Text(
                                  review['user_name'] != null
                                      ? review['user_name'][0].toUpperCase()
                                      : '?',
                                  style: const TextStyle(color: Colors.white),
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      review['user_name'] ?? 'Anonymous',
                                      style: const TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 16,
                                      ),
                                    ),
                                    if (review['user_phone'] != null)
                                      Text(
                                        review['user_phone'],
                                        style: const TextStyle(
                                          color: Colors.grey,
                                          fontSize: 12,
                                        ),
                                      ),
                                  ],
                                ),
                              ),
                              Row(
                                children: List.generate(
                                  5,
                                      (starIndex) => Icon(
                                    starIndex < (review['rating'] ?? 0)
                                        ? Icons.star
                                        : Icons.star_border,
                                    color: Colors.amber,
                                    size: 20,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 12),
                          if (review['comment'] != null &&
                              review['comment'].isNotEmpty)
                            Text(
                              review['comment'],
                              style: const TextStyle(fontSize: 14),
                            ),
                          const SizedBox(height: 8),
                          Align(
                            alignment: Alignment.bottomRight,
                            child: Text(
                              review['created_at'] ?? '',
                              style: const TextStyle(
                                fontSize: 12,
                                color: Colors.grey,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              );
            },
          ),
        ),
      ),
    );
  }
}